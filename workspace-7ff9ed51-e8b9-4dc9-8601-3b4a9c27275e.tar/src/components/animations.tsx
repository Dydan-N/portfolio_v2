'use client'

import { useState, useEffect } from 'react'

export function ScrollReveal() {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('revealed')
          }
        })
      },
      { threshold: 0.1 }
    )

    const elements = document.querySelectorAll('.scroll-reveal')
    elements.forEach((el) => observer.observe(el))

    return () => {
      elements.forEach((el) => observer.unobserve(el))
    }
  }, [])

  return null
}

export function Typewriter({ text, delay = 50 }: { text: string; delay?: number }) {
  const [displayedText, setDisplayedText] = useState('')
  const [currentIndex, setCurrentIndex] = useState(0)

  useEffect(() => {
    if (currentIndex < text.length) {
      const timeout = setTimeout(() => {
        setDisplayedText(prev => prev + text[currentIndex])
        setCurrentIndex(prev => prev + 1)
      }, delay)

      return () => clearTimeout(timeout)
    }
  }, [currentIndex, text, delay])

  return <span>{displayedText}</span>
}

export function Counter({ end, duration = 2000 }: { end: number; duration?: number }) {
  const [count, setCount] = useState(0)

  useEffect(() => {
    let startTime: number | null = null
    const startValue = 0
    const endValue = end

    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime
      const progress = Math.min((currentTime - startTime) / duration, 1)

      setCount(Math.floor(progress * (endValue - startValue) + startValue))

      if (progress < 1) {
        requestAnimationFrame(animate)
      }
    }

    requestAnimationFrame(animate)
  }, [end, duration])

  return <span>{count}</span>
}

export function GlitchEffect({ text }: { text: string }) {
  const [isGlitching, setIsGlitching] = useState(false)

  const triggerGlitch = () => {
    setIsGlitching(true)
    setTimeout(() => setIsGlitching(false), 200)
  }

  useEffect(() => {
    const interval = setInterval(triggerGlitch, 5000)
    return () => clearInterval(interval)
  }, [])

  return (
    <span 
      className={`inline-block ${isGlitching ? 'animate-pulse' : ''}`}
      style={{
        textShadow: isGlitching 
          ? '2px 2px 0px #ff00ff, -2px -2px 0px #00ffff' 
          : 'none'
      }}
    >
      {text}
    </span>
  )
}

// Skill progress bar animation
export function SkillProgress({ skill, level, delay = 0 }: { skill: string; level: number; delay?: number }) {
  const [isVisible, setIsVisible] = useState(false)
  const [currentLevel, setCurrentLevel] = useState(0)

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true)
      const interval = setInterval(() => {
        setCurrentLevel(prev => {
          if (prev >= level) {
            clearInterval(interval)
            return level
          }
          return prev + 1
        })
      }, 20)
      return () => clearInterval(interval)
    }, delay)

    return () => clearTimeout(timer)
  }, [level, delay])

  return (
    <div className="space-y-2">
      <div className="flex justify-between items-center">
        <span className="text-sm tracking-wider">{skill}</span>
        <span className="text-xs text-gray-500">{currentLevel}%</span>
      </div>
      <div className="w-full h-px bg-white/10">
        <div 
          className="h-full bg-white/60 transition-all duration-500"
          style={{ width: `${currentLevel}%` }}
        />
      </div>
    </div>
  )
}
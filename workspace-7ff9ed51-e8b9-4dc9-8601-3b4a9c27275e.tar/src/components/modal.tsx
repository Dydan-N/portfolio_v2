'use client'

import { useState } from 'react'

interface ModalProps {
  isOpen: boolean
  onClose: () => void
  title: string
  content: string
}

export function Modal({ isOpen, onClose, title, content }: ModalProps) {
  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-8">
      <div className="bg-black border border-white/20 p-8 max-w-md w-full">
        <h3 className="text-2xl font-light tracking-wider mb-4">{title}</h3>
        <p className="text-gray-400 mb-6">{content}</p>
        <button
          onClick={onClose}
          className="w-full px-4 py-2 border border-white/20 text-white hover:bg-white hover:text-black transition-all duration-300"
        >
          Close
        </button>
      </div>
    </div>
  )
}

export function useModal() {
  const [isOpen, setIsOpen] = useState(false)
  const [title, setTitle] = useState('')
  const [content, setContent] = useState('')

  const openModal = (modalTitle: string, modalContent: string) => {
    setTitle(modalTitle)
    setContent(modalContent)
    setIsOpen(true)
  }

  const closeModal = () => {
    setIsOpen(false)
  }

  return {
    isOpen,
    title,
    content,
    openModal,
    closeModal
  }
}
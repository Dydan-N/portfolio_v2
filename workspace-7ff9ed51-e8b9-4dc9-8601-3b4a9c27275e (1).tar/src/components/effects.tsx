'use client'

import { useEffect, useRef } from 'react'

export function SmoothScroll() {
  useEffect(() => {
    // Smooth scrolling for anchor links
    const handleAnchorClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement
      const anchor = target.closest('a')
      
      if (anchor && anchor.hash) {
        e.preventDefault()
        const targetElement = document.querySelector(anchor.hash)
        
        if (targetElement) {
          targetElement.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
          })
        }
      }
    }

    document.addEventListener('click', handleAnchorClick)
    
    return () => {
      document.removeEventListener('click', handleAnchorClick)
    }
  }, [])

  return null
}

export function ScrollProgress() {
  const progressRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const updateProgress = () => {
      const scrollTop = window.scrollY
      const docHeight = document.documentElement.scrollHeight - window.innerHeight
      const scrollPercent = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0
      
      if (progressRef.current) {
        progressRef.current.style.width = `${scrollPercent}%`
      }
    }

    window.addEventListener('scroll', updateProgress)
    updateProgress()
    
    return () => {
      window.removeEventListener('scroll', updateProgress)
    }
  }, [])

  return (
    <div className="fixed top-0 left-0 w-full h-px bg-gray-900 z-50">
      <div 
        ref={progressRef}
        className="h-full bg-white transition-all duration-150"
        style={{ width: '0%' }}
      />
    </div>
  )
}

export function ParallaxEffect() {
  useEffect(() => {
    const handleScroll = () => {
      const scrolled = window.scrollY
      const parallaxElements = document.querySelectorAll('.parallax')
      
      parallaxElements.forEach((element) => {
        const speed = parseFloat(element.getAttribute('data-speed') || '0.5')
        const yPos = -(scrolled * speed)
        ;(element as HTMLElement).style.transform = `translateY(${yPos}px)`
      })
    }

    window.addEventListener('scroll', handleScroll)
    
    return () => {
      window.removeEventListener('scroll', handleScroll)
    }
  }, [])

  return null
}

export function MagneticButtons() {
  useEffect(() => {
    const magneticButtons = document.querySelectorAll('.magnetic')
    
    magneticButtons.forEach((button) => {
      const handleMouseMove = (e: MouseEvent) => {
        const rect = button.getBoundingClientRect()
        const x = e.clientX - rect.left - rect.width / 2
        const y = e.clientY - rect.top - rect.height / 2
        
        // Limit the movement range
        const maxDistance = 10
        const limitedX = Math.max(-maxDistance, Math.min(maxDistance, x * 0.2))
        const limitedY = Math.max(-maxDistance, Math.min(maxDistance, y * 0.2))
        
        ;(button as HTMLElement).style.transform = `translate(${limitedX}px, ${limitedY}px)`
      }
      
      const handleMouseLeave = () => {
        ;(button as HTMLElement).style.transform = 'translate(0, 0)'
      }
      
      button.addEventListener('mousemove', handleMouseMove)
      button.addEventListener('mouseleave', handleMouseLeave)
      
      return () => {
        button.removeEventListener('mousemove', handleMouseMove)
        button.removeEventListener('mouseleave', handleMouseLeave)
      }
    })
  }, [])

  return null
}

export function CursorGlow() {
  useEffect(() => {
    // Skip on touch devices
    if ('ontouchstart' in window) return null

    const cursor = document.createElement('div')
    cursor.className = 'cursor-glow'
    cursor.style.cssText = `
      position: fixed;
      width: 300px;
      height: 300px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(255, 255, 255, 0.02) 0%, transparent 70%);
      pointer-events: none;
      transform: translate(-50%, -50%);
      z-index: 1;
      transition: opacity 0.3s ease;
      opacity: 0;
    `
    document.body.appendChild(cursor)
    
    const handleMouseMove = (e: MouseEvent) => {
      cursor.style.left = e.clientX + 'px'
      cursor.style.top = e.clientY + 'px'
    }
    
    const handleMouseEnter = () => {
      cursor.style.opacity = '1'
    }
    
    const handleMouseLeave = () => {
      cursor.style.opacity = '0'
    }
    
    window.addEventListener('mousemove', handleMouseMove)
    document.addEventListener('mouseenter', handleMouseEnter)
    document.addEventListener('mouseleave', handleMouseLeave)
    
    return () => {
      window.removeEventListener('mousemove', handleMouseMove)
      document.removeEventListener('mouseenter', handleMouseEnter)
      document.removeEventListener('mouseleave', handleMouseLeave)
      if (cursor.parentNode) {
        cursor.parentNode.removeChild(cursor)
      }
    }
  }, [])

  return null
}
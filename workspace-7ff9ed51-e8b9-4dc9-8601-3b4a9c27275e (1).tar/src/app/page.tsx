'use client'

import { useState, useEffect, useRef } from 'react'
import { Menu, X, ChevronDown, Sparkles, Zap, Star, Heart, ArrowRight, MousePointer, Code, Palette, Rocket, Grid3x3, Layers, Diamond, User, Award, Target, Users, Calendar, MapPin, Mail, Phone, Github, Linkedin, Camera } from 'lucide-react'
import { SmoothScroll, ScrollProgress, ParallaxEffect, MagneticButtons, CursorGlow } from '@/components/effects'
import { FloatingElements, TextReveal, HoverCard, ScrollIndicator } from '@/components/interactive'
import { Modal, useModal } from '@/components/modal'
import { ScrollReveal } from '@/components/animations'

export default function PortfolioDidan() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const [scrollY, setScrollY] = useState(0)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const { isOpen, title, content, tech, openModal, closeModal } = useModal()

  // Mouse tracking
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY })
    }
    window.addEventListener('mousemove', handleMouseMove)
    return () => window.removeEventListener('mousemove', handleMouseMove)
  }, [])

  // Scroll tracking
  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  // Minimalist particle system
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const handleResize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    handleResize()
    window.addEventListener('resize', handleResize)

    const particles: Array<{
      x: number
      y: number
      vx: number
      vy: number
      size: number
      opacity: number
    }> = []

    // Create minimal particles
    for (let i = 0; i < 30; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.2,
        vy: (Math.random() - 0.5) * 0.2,
        size: Math.random() * 2 + 0.5,
        opacity: Math.random() * 0.3 + 0.1
      })
    }

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)
      
      particles.forEach(particle => {
        particle.x += particle.vx
        particle.y += particle.vy

        if (particle.x < 0 || particle.x > canvas.width) particle.vx *= -1
        if (particle.y < 0 || particle.y > canvas.height) particle.vy *= -1

        ctx.beginPath()
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(255, 255, 255, ${particle.opacity})`
        ctx.fill()
      })

      // Minimal connections
      particles.forEach((p1, i) => {
        particles.slice(i + 1).forEach(p2 => {
          const distance = Math.sqrt((p1.x - p2.x) ** 2 + (p1.y - p2.y) ** 2)
          if (distance < 150) {
            ctx.beginPath()
            ctx.moveTo(p1.x, p1.y)
            ctx.lineTo(p2.x, p2.y)
            ctx.strokeStyle = `rgba(255, 255, 255, ${0.05 * (1 - distance / 150)})`
            ctx.stroke()
          }
        })
      })

      requestAnimationFrame(animate)
    }

    animate()

    return () => {
      window.removeEventListener('resize', handleResize)
    }
  }, [])

  const navItems = [
    { name: 'Beranda', href: '#beranda' },
    { name: 'Tentang', href: '#tentang' },
    { name: 'Skills', href: '#skills' },
    { name: 'Portfolio', href: '#portfolio' },
    { name: 'Kontak', href: '#kontak' }
  ]

  const handleNavClick = (href: string) => {
    setIsMenuOpen(false)
    const element = document.querySelector(href)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <div className="min-h-screen bg-black text-white overflow-hidden relative">
      {/* Effects Components */}
      <SmoothScroll />
      <ScrollProgress />
      <ParallaxEffect />
      <MagneticButtons />
      <CursorGlow />
      <ScrollIndicator />
      <FloatingElements />
      <ScrollReveal />
      
      {/* Minimalist Background Canvas */}
      <canvas
        ref={canvasRef}
        className="fixed top-0 left-0 w-full h-full pointer-events-none z-0"
      />

      {/* Subtle Mouse Effect */}
      <div 
        className="fixed inset-0 opacity-10 z-0 pointer-events-none"
        style={{
          background: `radial-gradient(circle at ${mousePosition.x}px ${mousePosition.y}px, rgba(255, 255, 255, 0.05) 0%, transparent 40%)`
        }}
      />

      {/* Navigation */}
      <nav className="relative z-50 px-8 py-6">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 border border-white/20 flex items-center justify-center">
              <User className="w-4 h-4 text-white" />
            </div>
            <span className="text-xl font-light tracking-wider">
              DIDAN
            </span>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex space-x-12">
            {navItems.map((item, index) => (
              <button
                key={item.name}
                onClick={() => handleNavClick(item.href)}
                className="relative group text-sm tracking-widest uppercase text-gray-400 hover:text-white transition-colors duration-500"
                style={{
                  animationDelay: `${index * 0.1}s`
                }}
              >
                {item.name}
                <span className="absolute -bottom-2 left-0 w-0 h-px bg-white group-hover:w-full transition-all duration-500" />
              </button>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden relative z-50 border border-white/20 p-2"
          >
            {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        {/* Mobile Menu */}
        <div className={`md:hidden fixed inset-0 bg-black transform transition-transform duration-700 ${isMenuOpen ? 'translate-x-0' : 'translate-x-full'} z-40`}>
          <div className="flex flex-col items-center justify-center h-full space-y-12">
            {navItems.map((item, index) => (
              <button
                key={item.name}
                onClick={() => handleNavClick(item.href)}
                className="text-3xl font-light tracking-widest uppercase text-gray-400 hover:text-white transition-colors duration-500"
                style={{
                  animationDelay: `${index * 0.1}s`
                }}
              >
                {item.name}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="beranda" className="relative z-10 min-h-screen flex items-center justify-center px-8">
        <div className="max-w-7xl mx-auto w-full">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Left Content */}
            <div className="space-y-8">
              <div className="space-y-4">
                <div className="text-sm tracking-widest uppercase text-gray-500">
                  <TextReveal text="Hello, I'm" />
                </div>
                <h1 className="text-6xl md:text-8xl font-light leading-none">
                  <div className="overflow-hidden">
                    <span className="block animate-fade-in">
                      <TextReveal text="Didan" />
                    </span>
                  </div>
                  <div className="overflow-hidden">
                    <span className="block animate-fade-in animation-delay-300">
                      <TextReveal text="Ramdhani" />
                    </span>
                  </div>
                </h1>
                <div className="text-lg text-gray-400 space-y-2 animate-fade-in animation-delay-600">
                  <div className="flex items-center space-x-2">
                    <MapPin className="w-4 h-4" />
                    <span>Cimaragas, Kab. Ciamis, Jawa Barat</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Calendar className="w-4 h-4" />
                    <span>9 Oktober 2007 (18 tahun)</span>
                  </div>
                </div>
              </div>
              
              <p className="text-lg text-gray-400 leading-relaxed max-w-md animate-fade-in animation-delay-600">
                <TextReveal text="Fresh Graduate dari SMKN 1 Banjar dengan passion dalam programming dan organisasi." />
              </p>

              <div className="flex flex-col sm:flex-row gap-4 animate-fade-in animation-delay-900">
                <button 
                  onClick={() => handleNavClick('#portfolio')}
                  className="magnetic group relative px-8 py-4 bg-white text-black rounded-none font-medium text-sm tracking-widest uppercase hover:bg-gray-200 transition-all duration-300 overflow-hidden"
                >
                  <span className="relative z-10">Lihat Portfolio</span>
                  <div className="absolute inset-0 bg-gray-900 transform translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
                  <span className="absolute inset-0 flex items-center justify-center text-white transform translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                    Lihat Portfolio
                  </span>
                </button>
                <button 
                  onClick={() => handleNavClick('#kontak')}
                  className="magnetic px-8 py-4 border border-white/20 text-white rounded-none font-medium text-sm tracking-widest uppercase hover:border-white transition-all duration-300"
                >
                  Hubungi Saya
                </button>
              </div>
            </div>

            {/* Right Visual Element */}
            <div className="relative h-96 lg:h-full min-h-96">
              <div className="absolute inset-0 border border-white/10 transform rotate-3 hover:rotate-6 transition-transform duration-700" />
              <div className="absolute inset-4 border border-white/5 transform -rotate-3 hover:-rotate-6 transition-transform duration-700" />
              <div className="absolute inset-8 bg-gradient-to-br from-gray-900 to-black flex items-center justify-center">
                <div className="text-center space-y-4">
                  <User className="w-16 h-16 mx-auto text-white/20" />
                  <div className="text-2xl font-light tracking-widest text-gray-500">
                    DIDAN
                  </div>
                  <div className="text-sm text-gray-600">
                    Full Stack Developer
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
          <div className="flex flex-col items-center space-y-2">
            <span className="text-xs tracking-widest uppercase text-gray-500">Scroll</span>
            <ChevronDown className="w-4 h-4 text-white/40 animate-bounce" />
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="tentang" className="relative z-10 py-32 px-8">
        <div className="max-w-7xl mx-auto">
          <div className="mb-16">
            <h2 className="text-4xl md:text-6xl font-light tracking-wider mb-4">
              TENTANG SAYA
            </h2>
            <div className="w-24 h-px bg-white/20" />
          </div>

          <div className="grid lg:grid-cols-2 gap-16">
            <div className="space-y-8">
              <div>
                <h3 className="text-2xl font-light tracking-wider mb-4">Pendidikan</h3>
                <div className="space-y-4">
                  <div className="border-l-2 border-white/20 pl-6">
                    <h4 className="text-lg font-medium">SMKN 1 Banjar</h4>
                    <p className="text-gray-400">Fresh Graduate (2024)</p>
                    <p className="text-gray-500 text-sm mt-2">Lulusan dari jurusan yang relevan dengan teknologi dan programming</p>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-2xl font-light tracking-wider mb-4">Informasi Pribadi</h3>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <User className="w-5 h-5 text-white/60" />
                    <span>Didan Ramdhani</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <MapPin className="w-5 h-5 text-white/60" />
                    <span>Cimaragas, Kab. Ciamis, Jawa Barat</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Calendar className="w-5 h-5 text-white/60" />
                    <span>9 Oktober 2007 (18 tahun)</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-8">
              <div>
                <h3 className="text-2xl font-light tracking-wider mb-4">Organisasi</h3>
                <div className="space-y-4">
                  <div className="border-l-2 border-white/20 pl-6">
                    <h4 className="text-lg font-medium">Pramuka</h4>
                    <p className="text-gray-400">Aktif Berorganisasi</p>
                    <p className="text-gray-500 text-sm mt-2">Banyak pengalaman dalam organisasi pramuka yang membentuk karakter kepemimpinan dan kerjasama tim</p>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-2xl font-light tracking-wider mb-4">Soft Skills</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center space-x-2">
                    <Target className="w-4 h-4 text-white/60" />
                    <span className="text-sm">Tepat Waktu</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Zap className="w-4 h-4 text-white/60" />
                    <span className="text-sm">Gesit</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Users className="w-4 h-4 text-white/60" />
                    <span className="text-sm">Komunikasi</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Award className="w-4 h-4 text-white/60" />
                    <span className="text-sm">Kepemimpinan</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="relative z-10 py-32 px-8 border-t border-white/10">
        <div className="max-w-7xl mx-auto">
          <div className="mb-16">
            <h2 className="text-4xl md:text-6xl font-light tracking-wider mb-4">
              SKILLS
            </h2>
            <div className="w-24 h-px bg-white/20" />
          </div>

          <div className="grid lg:grid-cols-3 gap-16">
            <div className="scroll-reveal">
              <h3 className="text-xl font-light tracking-wider mb-6 text-gray-400">Programming Languages</h3>
              <div className="space-y-4">
                {[
                  { name: 'PHP', level: 75 },
                  { name: 'Python', level: 70 },
                  { name: 'Dart', level: 65 }
                ].map((skill) => (
                  <div key={skill.name} className="group">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm tracking-wider">{skill.name}</span>
                      <span className="text-xs text-gray-500">{skill.level}%</span>
                    </div>
                    <div className="w-full h-px bg-white/10">
                      <div className="h-full bg-white/60 w-0 group-hover:w-full transition-all duration-1000" style={{ width: `${skill.level}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="scroll-reveal">
              <h3 className="text-xl font-light tracking-wider mb-6 text-gray-400">Tools & Software</h3>
              <div className="space-y-4">
                {[
                  { name: 'AI Tools', level: 85 },
                  { name: 'Xampp', level: 80 },
                  { name: 'Laragon', level: 75 },
                  { name: 'VS Code', level: 90 },
                  { name: 'Qoder', level: 70 },
                  { name: 'Cursor', level: 75 }
                ].map((tool) => (
                  <div key={tool.name} className="group">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm tracking-wider">{tool.name}</span>
                      <span className="text-xs text-gray-500">{tool.level}%</span>
                    </div>
                    <div className="w-full h-px bg-white/10">
                      <div className="h-full bg-white/60 w-0 group-hover:w-full transition-all duration-1000" style={{ width: `${tool.level}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="scroll-reveal">
              <h3 className="text-xl font-light tracking-wider mb-6 text-gray-400">Database</h3>
              <div className="space-y-4">
                {[
                  { name: 'MongoDB', level: 70 },
                  { name: 'SQLite', level: 75 },
                  { name: 'MySQL', level: 80 }
                ].map((db) => (
                  <div key={db.name} className="group">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm tracking-wider">{db.name}</span>
                      <span className="text-xs text-gray-500">{db.level}%</span>
                    </div>
                    <div className="w-full h-px bg-white/10">
                      <div className="h-full bg-white/60 w-0 group-hover:w-full transition-all duration-1000" style={{ width: `${db.level}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="relative z-10 py-32 px-8 border-t border-white/10">
        <div className="max-w-7xl mx-auto">
          <div className="mb-16">
            <h2 className="text-4xl md:text-6xl font-light tracking-wider mb-4">
              PORTFOLIO
            </h2>
            <div className="w-24 h-px bg-white/20" />
          </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { 
                id: 1, 
                title: 'Web Application', 
                tech: 'PHP, MySQL', 
                description: 'Aplikasi web berbasis PHP dengan database MySQL untuk manajemen data'
              },
              { 
                id: 2, 
                title: 'Mobile App', 
                tech: 'Dart, Flutter', 
                description: 'Aplikasi mobile cross-platform dengan Flutter'
              },
              { 
                id: 3, 
                title: 'Data Analysis', 
                tech: 'Python, SQLite', 
                description: 'Analisis data dengan Python dan visualisasi hasil'
              },
              { 
                id: 4, 
                title: 'AI Integration', 
                tech: 'AI Tools, Python', 
                description: 'Integrasi AI tools dalam project untuk otomasi'
              },
              { 
                id: 5, 
                title: 'Database System', 
                tech: 'MongoDB, PHP', 
                description: 'Sistem database NoSQL dengan backend PHP'
              },
              { 
                id: 6, 
                title: 'Full Stack Project', 
                tech: 'PHP, MySQL, JS', 
                description: 'Project full stack lengkap dengan frontend dan backend'
              }
            ].map((project) => (
              <div
                key={project.id}
                className="group relative overflow-hidden border border-white/10 hover:border-white/30 transition-all duration-700 cursor-pointer bg-black/50 min-h-[250px] scroll-reveal"
                onClick={() => openModal(
                  project.title, 
                  project.description, 
                  project.tech.split(', ')
                )}
              >
                <div className="absolute inset-0 bg-gradient-to-br from-gray-900 to-black flex items-center justify-center">
                  <div className="text-center space-y-4">
                    <div className="w-16 h-16 mx-auto border border-white/20 rounded-lg flex items-center justify-center">
                      <Code className="w-8 h-8 text-white/60" />
                    </div>
                    <div className="text-lg font-light tracking-wider text-white">
                      {project.title}
                    </div>
                    <div className="text-xs text-gray-500">
                      {project.tech}
                    </div>
                  </div>
                </div>
                <div className="absolute inset-0 bg-white/5 transform translate-y-full group-hover:translate-y-0 transition-transform duration-700" />
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-700 bg-black/80">
                  <div className="text-center text-white p-4">
                    <p className="text-sm mb-2">{project.description}</p>
                    <p className="text-xs text-gray-300">Click for details</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="kontak" className="relative z-10 py-32 px-8 border-t border-white/10">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-6xl font-light tracking-wider mb-8">
            HUBUNGI SAYA
          </h2>
          <p className="text-lg text-gray-400 leading-relaxed mb-12">
            Mari terhubung dan diskusikan tentang project atau kolaborasi!
          </p>
          
          <div className="grid grid-cols-2 md:grid-cols-5 gap-6 mb-12">
            <button
              onClick={() => window.open('https://wa.me/6281234567890', '_blank')}
              className="magnetic group relative p-6 border border-white/20 hover:border-white/40 transition-all duration-300"
            >
              <div className="flex flex-col items-center space-y-3">
                <div className="w-12 h-12 border border-white/20 rounded-full flex items-center justify-center group-hover:bg-white group-hover:text-black transition-all duration-300">
                  <Phone className="w-6 h-6" />
                </div>
                <span className="text-sm tracking-wider">WhatsApp</span>
              </div>
            </button>

            <button
              onClick={() => window.open('https://www.instagram.com/didanramdhani', '_blank')}
              className="magnetic group relative p-6 border border-white/20 hover:border-white/40 transition-all duration-300"
            >
              <div className="flex flex-col items-center space-y-3">
                <div className="w-12 h-12 border border-white/20 rounded-full flex items-center justify-center group-hover:bg-white group-hover:text-black transition-all duration-300">
                  <Camera className="w-6 h-6" />
                </div>
                <span className="text-sm tracking-wider">Instagram</span>
              </div>
            </button>

            <button
              onClick={() => window.open('mailto:didanramdhani@email.com', '_blank')}
              className="magnetic group relative p-6 border border-white/20 hover:border-white/40 transition-all duration-300"
            >
              <div className="flex flex-col items-center space-y-3">
                <div className="w-12 h-12 border border-white/20 rounded-full flex items-center justify-center group-hover:bg-white group-hover:text-black transition-all duration-300">
                  <Mail className="w-6 h-6" />
                </div>
                <span className="text-sm tracking-wider">Email</span>
              </div>
            </button>

            <button
              onClick={() => window.open('https://www.linkedin.com/in/didanramdhani', '_blank')}
              className="magnetic group relative p-6 border border-white/20 hover:border-white/40 transition-all duration-300"
            >
              <div className="flex flex-col items-center space-y-3">
                <div className="w-12 h-12 border border-white/20 rounded-full flex items-center justify-center group-hover:bg-white group-hover:text-black transition-all duration-300">
                  <Linkedin className="w-6 h-6" />
                </div>
                <span className="text-sm tracking-wider">LinkedIn</span>
              </div>
            </button>

            <button
              onClick={() => window.open('https://github.com/didanramdhani', '_blank')}
              className="magnetic group relative p-6 border border-white/20 hover:border-white/40 transition-all duration-300"
            >
              <div className="flex flex-col items-center space-y-3">
                <div className="w-12 h-12 border border-white/20 rounded-full flex items-center justify-center group-hover:bg-white group-hover:text-black transition-all duration-300">
                  <Github className="w-6 h-6" />
                </div>
                <span className="text-sm tracking-wider">GitHub</span>
              </div>
            </button>
          </div>

          <div className="text-sm text-gray-500">
            <p>Cimaragas, Kab. Ciamis, Jawa Barat</p>
            <p className="mt-2">© 2024 Didan Ramdhani - All rights reserved</p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 py-16 px-8 border-t border-white/10">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-3 mb-8 md:mb-0">
              <div className="w-8 h-8 border border-white/20 flex items-center justify-center">
                <User className="w-4 h-4 text-white" />
              </div>
              <span className="text-xl font-light tracking-wider">
                DIDAN RAMDHANI
              </span>
            </div>
            <div className="text-sm text-gray-500">
              © 2024 — Fresh Graduate Developer
            </div>
          </div>
        </div>
      </footer>

      {/* Modal Component */}
      <Modal 
        isOpen={isOpen}
        onClose={closeModal}
        title={title}
        content={content}
        tech={tech}
      />

      <style jsx>{`
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(30px); }
          to { opacity: 1; transform: translateY(0); }
        }

        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-20px) rotate(180deg); }
        }

        @keyframes slide-in-left {
          from { opacity: 0; transform: translateX(-50px); }
          to { opacity: 1; transform: translateX(0); }
        }

        @keyframes slide-in-right {
          from { opacity: 0; transform: translateX(50px); }
          to { opacity: 1; transform: translateX(0); }
        }

        .animate-fade-in {
          animation: fade-in 1.2s ease-out forwards;
          opacity: 0;
        }

        .animate-float {
          animation: float 8s ease-in-out infinite;
        }

        .animate-slide-left {
          animation: slide-in-left 1s ease-out forwards;
          opacity: 0;
        }

        .animate-slide-right {
          animation: slide-in-right 1s ease-out forwards;
          opacity: 0;
        }

        .animation-delay-300 {
          animation-delay: 0.3s;
        }

        .animation-delay-600 {
          animation-delay: 0.6s;
        }

        .animation-delay-900 {
          animation-delay: 0.9s;
        }

        .magnetic {
          transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .parallax {
          will-change: transform;
        }

        .scroll-reveal {
          opacity: 0;
          transform: translateY(50px);
          transition: all 0.8s ease-out;
        }

        .scroll-reveal.revealed {
          opacity: 1;
          transform: translateY(0);
        }

        /* Custom scrollbar */
        ::-webkit-scrollbar {
          width: 6px;
        }

        ::-webkit-scrollbar-track {
          background: rgba(0, 0, 0, 0.1);
        }

        ::-webkit-scrollbar-thumb {
          background: rgba(255, 255, 255, 0.2);
          border-radius: 3px;
        }

        ::-webkit-scrollbar-thumb:hover {
          background: rgba(255, 255, 255, 0.3);
        }

        /* Smooth scroll behavior */
        html {
          scroll-behavior: smooth;
        }

        /* Button focus states */
        button:focus {
          outline: 2px solid white;
          outline-offset: 2px;
        }

        /* Interactive elements */
        .interactive-element {
          cursor: pointer;
          user-select: none;
        }

        .interactive-element:hover {
          transform: scale(1.02);
        }

        .interactive-element:active {
          transform: scale(0.98);
        }
      `}</style>
    </div>
  )
}